AUREVANT WEBSITE
Files:
- index.html
- logo.jpg
- cover.jpg

GitHub Pages:
1. Open your aurevant-website repository.
2. Upload these three files to the repository root.
3. If index.html already exists, replace it with this one.
4. Commit changes to main.
5. Open Settings > Pages and use main / root if needed.
